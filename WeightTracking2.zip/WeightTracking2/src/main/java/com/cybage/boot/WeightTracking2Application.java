package com.cybage.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeightTracking2Application {

	public static void main(String[] args) {
		SpringApplication.run(WeightTracking2Application.class, args);
	}

}
