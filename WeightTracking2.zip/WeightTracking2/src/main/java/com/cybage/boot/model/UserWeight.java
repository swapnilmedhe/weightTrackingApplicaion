package com.cybage.boot.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="userWeight")
public class UserWeight {
	
	
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int wId;
	
	@Column(name = "weight")
	String weight;
	
	 @Column(nullable = false, updatable = false)
	 @CreationTimestamp
	 private Date time;
	 
	 @ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "uId")
	 private User user1;
	 
	 public UserWeight() {
		// TODO Auto-generated constructor stub
	}

	

	public UserWeight(@NotNull int wId, String weight, Date time, User user1) {
		super();
		this.wId = wId;
		this.weight = weight;
		this.time = time;
		this.user1 = user1;
	}



	public int getwId() {
		return wId;
	}

	public void setwId(int wId) {
		this.wId = wId;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}


	@JsonIgnore
	public User getUser1() {
		return user1;
	}



	@JsonIgnore
	public void setUser1(User user1) {
		this.user1 = user1;
	}

	
	 
	 
	

}
