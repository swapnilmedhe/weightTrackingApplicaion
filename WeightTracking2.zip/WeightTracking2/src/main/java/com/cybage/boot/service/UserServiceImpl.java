package com.cybage.boot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.cybage.boot.model.User;
import com.cybage.boot.model.UserWeight;
import com.cybage.boot.repository.UserRepository;
import com.cybage.boot.repository.UserWeightRepository;

@Service
public class UserServiceImpl implements UserService{
	 
	@Autowired
	 private UserRepository userRepository;
	 
	 @Autowired
	 private UserWeightRepository weightRepository;

	@Override
	public boolean saveUser(User user) {
		
		if(userRepository.findByEmail(user.getEmail()) == null){
			userRepository.save(user);
			return true;
		}
		else{
			return false;
		}
	}

	@Override
	public User findUserByEmailAndPassword(String email, String password) {
		
		return userRepository.findByEmailAndPassword(email, password);
	
	}

	@Override
	public boolean addWeight(UserWeight weight,int uId) {
		
		userRepository.findById(uId).map(data -> {
			weight.setUser1(data);
			return weightRepository.save(weight);
			});	
		return true;
	}

	@Override
	public List<UserWeight> getUserWeight(int uId) {
		List<UserWeight> weight = new ArrayList<>();
		weightRepository.findByUser1UserId(uId).forEach(weight::add);
		return weight;
	}
	
	@Override
	public boolean updateWeight(UserWeight weight) {
			String w = weight.getWeight();
			System.out.println(w);
			weightRepository.updateWeight(weight.getWeight(), weight.getwId());
		
			return true;
	}

	@Override
	public boolean deleteWeight(int wId) {
		
		weightRepository.deletWeight(wId);		
			
		return true;
	}

}
