import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserWeightChartComponent } from './user-weight-chart.component';

describe('UserWeightChartComponent', () => {
  let component: UserWeightChartComponent;
  let fixture: ComponentFixture<UserWeightChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserWeightChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserWeightChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
