import { Component } from '@angular/core';

const data = {
  "chart": {
    "caption": "Weight of User",
    "yaxisname": "Weight (in kg)",
    //"subcaption": "[2005-2016]",
    "numbersuffix": " kg",
    "rotatelabels": "1",
    "setadaptiveymin": "1",
    "theme": "candy"
  },
  "data": [
    {
      "label": "2018-02-28",
      "value": "51"
    },
    {
      "label": "2018-02-28",
      "value": "52"
    },
    {
      "label": "2018-02-28",
      "value": "53"
    },
    {
      "label": "2018-02-28",
      "value": "54"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    },
    {
      "label": "2018-02-28",
      "value": "55"
    }
  ]
};

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {

  constructor() {
    
  }

  // width = 1000;
  // height = 600;
  // type = 'line';
  // dataFormat = 'json';
  // dataSource = data;

}
