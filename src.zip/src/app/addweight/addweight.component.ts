import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { WeightService } from 'src/shared/weight.service';
import { User } from 'src/model/User';
import { UserWeight } from 'src/model/UserWeight';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-addweight',
  templateUrl: './addweight.component.html',
  styleUrls: ['./addweight.component.css']
})
export class AddweightComponent implements OnInit {

 
  @Input() isAdd = false;
  @Input() userId ;
  @Input() userWeight: UserWeight =  new UserWeight();
  submitted = false;
  @Output() completed: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    private weightService: WeightService,
    private router: Router,
    private route : ActivatedRoute,
    public ngModal: NgbActiveModal
    ) { }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
    this.addWeight();
  }

  newUserWeight(): void {
    this.submitted = false;
    this.userWeight = new UserWeight();
  }

  addWeight() {
   // console.log("in weight");
    this.weightService.addWeight(this.userWeight,this.userId).subscribe( data => {
        this.completed.emit(true);
        //this.ngModal.close();
    }, err => this.completed.emit(false));
  }
}
