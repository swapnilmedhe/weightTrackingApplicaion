import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { User } from 'src/model/User';
import { UserService } from 'src/shared/user.service';

@Component({
  selector: 'app-login-register',
  templateUrl: './login-register.component.html',
  styleUrls: ['./login-register.component.css']
})
export class LoginRegisterComponent implements OnInit {

  user: User;
  showLogin = true;
  message = '';
  loading: boolean;
  email: string;
  password: string;
  constructor(private router: Router, private userService: UserService) {
   
   
   
   
    // if (localStorage.getItem('currentUser')) {
    //   this.user = JSON.parse(localStorage.getItem('currentUser'));
    //  // const isToken = localStorage.getItem('token');
    //   //if ( this.user ) {
    //    // if ( this.user.Roles.includes(1)) {
    //      // localStorage.setItem('currentUser', JSON.stringify(this.user));
    //       //this.router.navigate(['/admin']); } else 
    //      // if ( this.user.Roles.includes(2)) {
    //       localStorage.setItem('currentUser', JSON.stringify(this.user));
    //       this.router.navigate(['/user']);
    //     //}
    //   } else {
    //     this.user = new User();
    // }
  }
  ngOnInit() {
  }


  onSubmitLogin() {
    console.log(this.email);
    console.log(this.password);
    
    
    if (!this.email || !this.password) {
      alert('Fields cant be empty');
      return;
    }
   
    this.userService.loginUser(this.email, this.password).subscribe(response => {

      const result = JSON.stringify(response);
     console.log(result);
     
        localStorage.setItem('curuser', JSON.stringify(response));
        this.router.navigate(['/dashboard']);
      

     
      //window.location.reload();
    },err => this.message = "Invalid Credentials" );
  }

  // loginUser() {
  //   this.loading = true;
  //   this._userService.loginUser(this.user.email, this.user.password).subscribe(user => {
  //     console.log(user);
  //     // if (user.Roles.includes(-1)) {
  //     //   this.loading = false;
  //     //   this.message = 'Email or password is incorrect';
  //     // } else if ( user.Roles.includes(1)) {
  //     //   localStorage.setItem('token', Md5.hashStr(JSON.stringify(user) ).toString());
  //     //   localStorage.setItem('currentUser', JSON.stringify(user));
  //     //   this.userService.user = user;
  //     //   this.router.navigate(['/admin']);
  //     //} else 
  //     //if ( user.Roles.includes(2)) {
  //       //localStorage.setItem('token', Md5.hashStr(JSON.stringify(user)).toString());
  //       localStorage.setItem('currentUser', JSON.stringify(user));
  //       this.userService.user = user;
  //       this.router.navigate(['/']);
  //   });
  // }

  // registerUser(form) {
  //   //console.log(form);
  //   //console.log(this.user);
  //   this._userService.registerUser(this.user).subscribe( data => console.log(data), error => console.log(error));
  //    // this.message = msg;
  //     //if ( this.message === 'Registration successful') {
  //       this.user = new User();
  //     //}
  //   //});
  // }

}
