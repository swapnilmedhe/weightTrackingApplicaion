import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserWeightComponent } from './user-weight/user-weight.component';
import { UserWeightChartComponent } from './user-weight-chart/user-weight-chart.component';
import { LoginRegisterComponent } from './auth/login-register/login-register.component';
import { AddweightComponent } from './addweight/addweight.component';
import { WeightUpdateDeleteComponent } from './weight-update-delete/weight-update-delete.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full'},
  { path: 'login', component: LoginRegisterComponent },
  { path: 'dashboard', component: WeightUpdateDeleteComponent },
  { path: 'addweight', component: AddweightComponent },
  { path: 'showchart', component: UserWeightChartComponent }
  // { path: '**', redirectTo: '/login'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
