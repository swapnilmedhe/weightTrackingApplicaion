import { Component, OnInit } from '@angular/core';
import { WeightService } from 'src/shared/weight.service';
import { UserWeight } from 'src/model/UserWeight';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-user-weight',
  templateUrl: './user-weight.component.html',
  styleUrls: ['./user-weight.component.css']
})
export class UserWeightComponent implements OnInit {

  data: any;

  userWeightData: UserWeight[] = [];
  userId: number = 1;

  constructor(private weightService: WeightService) { 
    this.data = {

      "chart": {
        "caption": "Weight of User",
        "yaxisname": "Weight (in kg)",
        //"subcaption": "[2005-2016]",
        "numbersuffix": " kg",
        "rotatelabels": "1",
        "setadaptiveymin": "1",
        "theme": "candy"
      },
      data: []
    }
  }

  ngOnInit() {

    this.weightService.getUserWeight(this.userId).subscribe(data => {
      data.forEach( weight => {
        const value: string = new DatePipe('en-US').transform(weight.time, 'dd MMM yy hh:mm');
        console.log(value);        
        this.data.data.push({ label: value, value: weight.weight });
      });
      
    })
  }

  width = 1000;
  height = 600;
  type = 'line';
  dataFormat = 'json';
  dataSource = 'data';
}
