import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// Import angular-fusioncharts
import { FusionChartsModule } from 'angular-fusioncharts';

// Import FusionCharts library
import * as FusionCharts from 'fusioncharts';

// Load FusionCharts Individual Charts
import * as Charts from 'fusioncharts/fusioncharts.charts';

// Load fusion theme
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';

import * as Candy from 'fusioncharts/themes/fusioncharts.theme.candy';

import * as TimeSeries from 'fusioncharts/fusioncharts.timeseries';
import { UserWeightComponent } from './user-weight/user-weight.component';
import { HttpClientModule } from '@angular/common/http';
import { UserWeightChartComponent } from './user-weight-chart/user-weight-chart.component';
import { LoginRegisterComponent } from './auth/login-register/login-register.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AddweightComponent } from './addweight/addweight.component';
import { WeightUpdateDeleteComponent } from './weight-update-delete/weight-update-delete.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UpdateWeightComponent } from './update-weight/update-weight.component';
// Use fcRoot function to inject FusionCharts library, and the modules you want to use
FusionChartsModule.fcRoot(FusionCharts, Charts, TimeSeries, FusionTheme, Candy)
import {NgxPaginationModule} from 'ngx-pagination';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [
    AppComponent,
    UserWeightComponent,
    UserWeightChartComponent,
    LoginRegisterComponent,
    AddweightComponent,
    WeightUpdateDeleteComponent,
    UpdateWeightComponent,
    FooterComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule ,
    FusionChartsModule, 
    ReactiveFormsModule,
    FormsModule, NgbModule,
    NgxPaginationModule
  ],
  providers: [ ],
  bootstrap: [AppComponent],
  entryComponents: [ AddweightComponent, UpdateWeightComponent ]
})
export class AppModule { }
