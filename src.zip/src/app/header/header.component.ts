import { User } from 'src/model/User';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  message: String;
  user:User;

  constructor(private router: Router) { }

  ngOnInit() {
    if (localStorage.getItem('curuser')) {
      this.user = JSON.parse(localStorage.getItem('curuser'));
  }
  }
  logout(): void {

    if ( confirm('Are you sure?')){

    

    localStorage.setItem('curuser', null);
    this.user = null;
    this.message = "You Are Logged Out !!"
    alert('Logged Out');
    this.router.navigate(['login']);
    }
  }

}
