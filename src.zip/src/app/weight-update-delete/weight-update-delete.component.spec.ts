import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeightUpdateDeleteComponent } from './weight-update-delete.component';

describe('WeightUpdateDeleteComponent', () => {
  let component: WeightUpdateDeleteComponent;
  let fixture: ComponentFixture<WeightUpdateDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeightUpdateDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeightUpdateDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
