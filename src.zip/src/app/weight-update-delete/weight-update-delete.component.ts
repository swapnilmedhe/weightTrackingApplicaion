import { Component, OnInit } from '@angular/core';
import { WeightService } from 'src/shared/weight.service';
import { UserWeight } from 'src/model/UserWeight';
import { Router, ActivatedRoute } from '@angular/router';
import { log } from 'util';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddweightComponent } from '../addweight/addweight.component';
import { UpdateWeightComponent } from '../update-weight/update-weight.component';
import { User } from 'src/model/User';

@Component({
  selector: 'app-weight-update-delete',
  templateUrl: './weight-update-delete.component.html',
  styleUrls: ['./weight-update-delete.component.css']
})
export class WeightUpdateDeleteComponent implements OnInit {

  userWeightData: UserWeight[] = [];
  wId: number;
  user: User;
  userWeight:  UserWeight;
  fName: String;
  lName: String;
  message: String;

  totalRec : number; //for pagination
  page: number = 1; //for pagination

  constructor(private weightService: WeightService,
    private router: Router,
    private ngModalService: NgbModal
    ) { }

  ngOnInit() {
    console.log('in on init');
    if (localStorage.getItem('curuser')) {
      this.user = JSON.parse(localStorage.getItem('curuser'));
      this.fName = this.user.fName;
      this.lName = this.user.lName;
      //console.log(this.user.uId);
      
    }
    this.initializeWeight();
  }

  deleteWeight(wId): void {
    if ( confirm('Are you sure?') ) {
      this.weightService.deleteWeight(wId).subscribe(data => {
        this.initializeWeight();
      }, err => alert(err));
    }
  };

  initializeWeight() {
    this.weightService.getUserWeight(this.user.uId).subscribe(data => {
      this.userWeightData = data;   
      this.totalRec = data.length; //for pagination
      console.log(this.totalRec); //for pagination
      console.log(this.page);  //for pagination
    });
  }

  // editUser(user: User): void {
  //   localStorage.removeItem("editUserId");
  //   localStorage.setItem("editUserId", user.id.toString());
  //   this.router.navigate(['edit-user']);
  // };

  updateWeight(userWeight): void {
    const modalRef = this.ngModalService.open(UpdateWeightComponent);
    modalRef.componentInstance.userWeight = userWeight;
    modalRef.componentInstance.isUpdate = true;
    modalRef.componentInstance.completed.subscribe( data => {
      if ( data === true ) { 
        this.initializeWeight();
      }
    });
    
  }

  addWeight(): void {
    const modalRef = this.ngModalService.open(AddweightComponent);
    modalRef.componentInstance.userId = this.user.uId;
    modalRef.componentInstance.isAdd = true;
    modalRef.componentInstance.completed.subscribe( data => {
      if ( data === true ) { 
        this.initializeWeight();
      }
    });
  };

  showChart(): void {
    this.router.navigate(['/showchart']);  }

    logout(): void {
      localStorage.setItem('curuser', null);
      this.user = null;
      this.message = "You Are Logged Out !!"
      alert('Logged Out');
      this.router.navigate(['login']);
    }

}
