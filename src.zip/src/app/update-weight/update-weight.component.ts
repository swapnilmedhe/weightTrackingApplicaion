import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { UserWeight } from 'src/model/UserWeight';
import { Router, ActivatedRoute } from '@angular/router';
import { WeightService } from 'src/shared/weight.service';
@Component({
  selector: 'app-update-weight',
  templateUrl: './update-weight.component.html',
  styleUrls: ['./update-weight.component.css']
})
export class UpdateWeightComponent implements OnInit {


  @Input() isAdd = false;
  @Input() userId ;
  @Input() userWeight: UserWeight ;
  submitted = false;
  @Output() completed: EventEmitter<boolean> = new EventEmitter<boolean>();

 

  constructor(
    private weightService: WeightService,
    private router: Router,
    private route : ActivatedRoute,
    public ngModal: NgbActiveModal
  ) { }

  ngOnInit() {
    
  }

  onSubmit() {
    this.submitted = true;
    this.updateWeight();
  }


  newUserWeight(): void {
    this.submitted = false;
    this.userWeight = new this.updateWeight();
  }

  updateWeight(){
    console.log(this.userWeight);
    
    this.weightService.updateWeight(this.userWeight).subscribe( data => {
      this.completed.emit(true);
      //this.ngModal.close();
  }, err => this.completed.emit(false));
}

  }

