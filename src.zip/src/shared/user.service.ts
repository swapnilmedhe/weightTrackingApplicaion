import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/model/User';

@Injectable({
    providedIn: 'root'
})
export class UserService {
    apiURL = 'http://localhost:8080/';
    user: User;

    constructor(private httpAPIClient: HttpClient) {
        if ( localStorage.getItem('currentUser') && localStorage.getItem('token') ) {
            this.user = JSON.parse(localStorage.getItem('currentUser'));
        }
    }
    
    loginUser(email, password): Observable<User> {
        console.log(email+"s");
        var body = {
                            email : email,
                            password : password
                };
        return this.httpAPIClient.post<User>(this.apiURL + 'login', body);
    }

    custlogin(email, pass): Observable<any> {
        const url = `${this.apiURL}${email}/${pass}`;
        return this.httpAPIClient.get(url);
      }

    // public login(email, password) {
    //     var body = {
    //                 email : email,
    //                 password : password
    //     };
    //     let header = new Headers({'Content-Type': 'application/json'});
    //      return this.http.post(this.url + '/login', body);//,requestOption);
    // }

    registerUser(user: User): Observable<Object> {
        return this.httpAPIClient.post(this.apiURL + 'register', user);
    }
}
