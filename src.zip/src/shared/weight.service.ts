import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserWeight } from 'src/model/UserWeight';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeightService {

  SERVER_URL: string = "http://localhost:8080/";

  constructor(private httpClient: HttpClient) { }


  public getUserWeight(uId: number){
    return this.httpClient.get<UserWeight[]>(this.SERVER_URL + 'getweight/'  + uId); 
}

public addWeight(add: UserWeight, uId: number): Observable<any> {
  // console.log("in add2");
   
         return this.httpClient.post<any>(`${this.SERVER_URL}addweight/${uId}`, add);
 }

 public deleteWeight(wId: number): Observable<any>{
  return this.httpClient.delete<any>(this.SERVER_URL + 'deleteweight/' + wId);
 }

 public updateWeight(update: UserWeight): Observable<any> {
  // console.log("in add2");
   console.log(update.weight);
   
         return this.httpClient.put<any>(`${this.SERVER_URL}updateweight`, update);
 }

//  loginUser(email, password): Observable<User> {
//   console.log(email+"s");
//   var body = {
//                       email : email,
//                       password : password
//           };
//   return this.httpAPIClient.post<User>(this.apiURL + 'login', body);
// }

}
