export class UserWeight {
    
    wId: number;
	
	weight: string;
    
    time: Date;
}