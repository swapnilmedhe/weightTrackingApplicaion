export class User {

    uId: number;
	
	fName: String;
	
	lName: String;
	
	email: String;
	
	password: String;
	
}
    